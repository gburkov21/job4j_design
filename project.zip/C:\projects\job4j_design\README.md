# job4j_design

## Проект на уровне изучения Java Junior

### Параметризованные типы, Wildcard.
### ООД
### GC
### Память
### Ввод-вывод, Socket
### SQl, JDBC

